<html>
    <head></head>
    <body>
        <form method="post" action="{{url('payment')}}">
            @csrf
            <span>User Id</span>
           <select name="user_id">
                @foreach ($data as $item)
                    <option value="{{$item->id}}">{{$item->name}}</option>
                @endforeach
           </select>
            <span>Amount</span>
            <input type="number" name="payment" />
            <input type="submit" value="Payment Now" />
        </form>
    </body>
</html>
