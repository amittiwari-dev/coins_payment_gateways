<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Confirmation</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container mt-5">
        <div class="card text-center">
            <div class="card-header">
                <h2>Payment Successful!</h2>
            </div>
            <div class="card-body">
                <h5 class="card-title">Thank you for your joins us!</h5>
                <p class="card-text">Your payment has been processed successfully.</p>
                <div class="mt-4">
                    <h6>Transaction Details:</h6>
                    <ul class="list-unstyled">
                        <li><strong>Transaction ID:</strong> {{$data['txn_id']}}</li>
                        <li><strong>Amount:</strong> {{$data['amount']}}</li>
                        <li><strong>Date:</strong> September 26, 2024</li>
                        {{-- <li><strong>Date:</strong> September 26, 2024</li> --}}
                    </ul>
                </div>
                <a href="{{url('/')}}" class="btn btn-primary">Return to Home</a>
            </div>
            <div class="card-footer text-muted">
                If you have any questions, feel free to contact our support team.
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
