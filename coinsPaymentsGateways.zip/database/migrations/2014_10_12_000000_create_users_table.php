<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email')->unique();
            $table->string('password');
            $table->timestamps();
        });
        Schema::create('payment', function (Blueprint $table) {
            $table->id();
            $table->string('payment');
            $table->unsignedBigInteger('user_id'); // Define the column
            $table->foreign('user_id') // Reference the 'user_id' column
            ->references('id')   // This references the 'id' column on the 'users' table
            ->on('users')        // This is the table we are referencing
            ->onDelete('cascade'); // Optional: define the action on delete
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};
