<html>
    <head></head>
    <body>
        <form method="post" action="<?php echo e(url('payment')); ?>">
            <?php echo csrf_field(); ?>
            <span>User Id</span>
           <select name="user_id">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
            <span>Amount</span>
            <input type="number" name="payment" />
            <input type="submit" value="Payment Now" />
        </form>
    </body>
</html>
<?php /**PATH C:\AmitDev\Laravel\TestingPaymentGateWay\example-app\resources\views/payment.blade.php ENDPATH**/ ?>