<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CoinPaymentController;
use App\Http\Controllers\PaymentController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [CoinPaymentController::class ,'paymentUSerData']);
Route::post('/payment', [CoinPaymentController::class ,'payment']);
Route::post('/payment-data', [CoinPaymentController::class ,'handleAPI'])->name('payment-data');






Route::post('/create-payment', [PaymentController::class, 'payment'])->name('payment.create');
Route::get('/payment-success', [PaymentController::class, 'paymentSuccess'])->name('payment.success');
Route::get('/payment-cancel', [PaymentController::class, 'paymentCancel'])->name('payment.cancel');
Route::post('/payment-ipn', [PaymentController::class, 'ipn'])->name('payment.ipn');

