<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;   // this is for use api to advanced server
use Illuminate\Support\Facades\DB;
class CoinPaymentController extends Controller
{
    protected $client;
    protected $publicKey;
    protected $privateKey;
    private $ch = null;

    public function __construct()
    {
        $this->client = new Client();
        $this->publicKey = '91ccb49318cd7e6c4a6ac88650f33103cf8e279e6a336c29ebd86319d58ab2a8';
        $this->privateKey = 'A1Dab78d356456359eFC7521d85b787868d5Ad669D90fa160733253e8e7C2CFA';
        $this->ch=null;
    }

    public function register(Request $req)
    {

    }
    public function payment(Request $req)
    {
            // here code for getting data of payment using from
            $amount = $req->payment; // Amount in currency units
            $currency1 = 'USD'; // Currency you're accepting
            $currency2 = 'LTCT'; // Cryptocurrency you want to receive
            $cmd='create_transaction';

            $req = array(
                'amount' => $req->payment,
                'currency1' => $currency1,
                'currency2' => $currency2,
                'buyer_email' => 'payment@gmail.com',
                'user_id'=>$req->user_id,
            //   'address' => $address,
                // 'ipn_url' => $ipn_url,
            );
            $response = $this->api_call($cmd, $req);

            if (isset($response['error']) && $response['error'] === 'ok') {
                // Success
              return redirect($response['result']['checkout_url']);
            } else {
                // Error handling
                echo 'Error: ' . $response['error'];
            }
    }
    public function paymentUSerData()
    {
        $result=DB::table('users')->get();
        return view('payment',['data'=>$result]);
    }


    // here code for connect the payment gateways
    private function api_call($cmd, $req = array()) {


		// Set the API command and required fields
    	$req['version'] = 1;
		$req['cmd'] = $cmd;
		$req['key'] =  $this->publicKey;
		$req['format'] = 'json'; //supported values are json and xml

		// Generate the query string
		$post_data = http_build_query($req, '', '&');

		// Calculate the HMAC signature on the POST data
		$hmac = hash_hmac('sha512', $post_data, $this->privateKey);

		// Create cURL handle and initialize (if needed)
		if ($this->ch === null) {
			$this->ch = curl_init('https://www.coinpayments.net/api.php');
			curl_setopt($this->ch, CURLOPT_FAILONERROR, TRUE);
			curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, TRUE);
			curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, 0);
		}
		curl_setopt($this->ch, CURLOPT_HTTPHEADER, array('HMAC: '.$hmac));
		curl_setopt($this->ch, CURLOPT_POSTFIELDS, $post_data);

		$data = curl_exec($this->ch);
		if ($data !== FALSE) {
			if (PHP_INT_SIZE < 8 && version_compare(PHP_VERSION, '5.4.0') >= 0) {
				// We are on 32-bit PHP, so use the bigint as string option. If you are using any API calls with Satoshis it is highly NOT recommended to use 32-bit PHP
				$dec = json_decode($data, TRUE, 512, JSON_BIGINT_AS_STRING);
			} else {
				$dec = json_decode($data, TRUE);
			}
			if ($dec !== NULL && count($dec)) {
				return $dec;
			} else {
				// If you are using PHP 5.5.0 or higher you can use json_last_error_msg() for a better error message
				return array('error' => 'Unable to parse JSON result ('.json_last_error().')');
			}
		} else {
			return array('error' => 'cURL error: '.curl_error($this->ch));
		}
	}





    // here handle for open payment method
    public function handleAPI(Request $req)
    {
        $params = $req->all();

        // Validate IPN response
        $response = $this->client->post('https://www.coinpayments.net/api/validate_ipn', [
            'json' => [
                'version' => 1,
                'key' => $this->publicKey,
                'cmd' => 'validate_ipn',
                'req' => $params,
            ]
        ]);

        $result = json_decode($response->getBody()->getContents(), true);

        if ($result['error'] === 'ok') {
            // Insert payment data into the database after successful IPN
            DB::table('payment')->insert([
                'user_id' => $req->user_id,
                'tracnation_id' => $result['result']['txn_id'],
                'payment' => $result['result']['amount'],
            ]);
        }

        return response()->json(['status' => 'success']);
    }


}
