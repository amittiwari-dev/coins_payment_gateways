<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\DB;

class PaymentController extends Controller
{
    protected $client;
    protected $publicKey;
    protected $privateKey;
    private $ch = null;

    public function __construct()
    {
        $this->client = new Client();
        $this->publicKey = 'd84bfb9d124b9fa6fc136fae2a8b485a75b71eff07a4a868bfe7c7e334657623';  // Replace with your actual public key
        $this->privateKey = 'a58E169aB68654b67C5D6df34eF0E56e2b1dF813117F6084f49223b1399205Bf'; // Replace with your actual private key
        $this->ch = null;
    }

    public function payment(Request $req)
    {
        // Gather data from the request
        $amount = $req->payment; // Amount in currency units
        $currency1 = 'USD'; // Currency you're accepting
        $currency2 = 'USDT.TRC20'; // Cryptocurrency you want to receive
        $cmd = 'create_transaction';

        // Request payload
        $apiRequest = array(
            'amount' => $amount,
            'currency1' => $currency1,
            'currency2' => $currency2,
            'buyer_email' => 'payment@gmail.com', // Change as needed
            'user_id' => $req->user_id,
        );

        // Call CoinPayments API to create the transaction
        $response = $this->api_call($cmd, $apiRequest);

        if (isset($response['error']) && $response['error'] === 'ok') {
            // Success, insert transaction details into the database
            // Redirect the user to the CoinPayments checkout page
            return redirect($response['result']['checkout_url']);
        } else {
            // Log the error for debugging purposes
            \Log::error('CoinPayments Error: ' . $response['error']);
            return back()->withErrors(['payment' => 'Payment initiation failed: ' . $response['error']]);
        }
    }

    public function paymentUserData()
    {
        // Fetch user data for the payment form
        $result = DB::table('users')->get();
        return view('payment', ['data' => $result]);
    }

    public function handleAPI(Request $req)
    {
        $params = $req->all();

        // Validate IPN response
        $response = $this->client->post('https://www.coinpayments.net/api/validate_ipn', [
            'json' => [
                'version' => 1,
                'key' => $this->publicKey,
                'cmd' => 'validate_ipn',
                'req' => $params,
            ]
        ]);

        $result = json_decode($response->getBody()->getContents(), true);

        if ($result['error'] === 'ok') {
            // Insert payment data into the database after successful IPN
            DB::table('payment')->insert([
                'user_id' => $req->user_id,
                'tracnation_id' => $result['result']['txn_id'],
                'payment' => $result['result']['amount'],
            ]);
        }

        return response()->json(['status' => 'success']);
    }

    // Function for making API calls to CoinPayments
    private function api_call($cmd, $req = array())
    {
        // Set API version, command, and key
        $req['version'] = 1;
        $req['cmd'] = $cmd;
        $req['key'] = $this->publicKey;
        $req['format'] = 'json'; // json format response

        // Build the query string
        $post_data = http_build_query($req, '', '&');

        // Generate HMAC signature
        $hmac = hash_hmac('sha512', $post_data, $this->privateKey);

        // Initialize cURL
        if ($this->ch === null) {
            $this->ch = curl_init('https://www.coinpayments.net/api.php');
            curl_setopt($this->ch, CURLOPT_FAILONERROR, TRUE);
            curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, TRUE);
            curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, 0);
        }

        curl_setopt($this->ch, CURLOPT_HTTPHEADER, array('HMAC: ' . $hmac));
        curl_setopt($this->ch, CURLOPT_POSTFIELDS, $post_data);

        // Execute API request
        $data = curl_exec($this->ch);
        if ($data !== FALSE) {
            if (PHP_INT_SIZE < 8 && version_compare(PHP_VERSION, '5.4.0') >= 0) {
                $dec = json_decode($data, TRUE, 512, JSON_BIGINT_AS_STRING);
            } else {
                $dec = json_decode($data, TRUE);
            }
            if ($dec !== NULL && count($dec)) {
                return $dec;
            } else {
                return array('error' => 'Unable to parse JSON result (' . json_last_error() . ')');
            }
        } else {
            return array('error' => 'cURL error: ' . curl_error($this->ch));
        }
    }
}
