<?php

namespace App\Services;

use GuzzleHttp\Client;

class CoinPaymentsService
{
    protected $client;
    protected $publicKey;
    protected $privateKey;
    // protected $ipnSecret;

    public function __construct()
    {
        $this->client = new Client();
        $this->publicKey = env('COINPAYMENTS_PUBLIC_KEY');
        $this->privateKey = env('COINPAYMENTS_PRIVATE_KEY');
        // $this->ipnSecret = env('COINPAYMENTS_IPN_SECRET');
    }

    private function sendRequest($method, $params = [])
    {
        $params['key'] = $this->publicKey;
        $params['version'] = 1;
        $params['format'] = 'json';
        $params['nonce'] = time();

        $params['signature'] = $this->generateSignature($params);

        $response = $this->client->request($method, 'https://www.coinpayments.net/api.php', [
            'form_params' => $params,
        ]);

        return json_decode($response->getBody(), true);
    }

    private function generateSignature($params)
    {
        ksort($params);
        $signature = '';

        foreach ($params as $key => $value) {
            $signature .= $key . '=' . $value . '&';
        }

        $signature = rtrim($signature, '&');
        return hash_hmac('sha512', $signature, $this->privateKey);
    }

    public function createTransaction($amount, $currency1, $currency2)
    {
        $params = [
            'amount' => $amount,
            'currency1' => $currency1,
            'currency2' => $currency2,
            // 'ipn_url' => $ipnUrl,
        ];

        return $this->sendRequest('POST', $params);
    }
}
